// deque_assignment.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <deque>
using namespace std;
#include "my_deque.h"
#include<string>
#include "my_deque_iterator.h"

int main()
{
	

	return success;
}
